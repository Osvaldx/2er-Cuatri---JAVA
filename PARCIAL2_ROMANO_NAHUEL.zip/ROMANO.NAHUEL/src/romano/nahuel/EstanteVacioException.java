package romano.nahuel;

public class EstanteVacioException extends Exception {

    public EstanteVacioException(String message) {
        super(message);
    }
    
}
