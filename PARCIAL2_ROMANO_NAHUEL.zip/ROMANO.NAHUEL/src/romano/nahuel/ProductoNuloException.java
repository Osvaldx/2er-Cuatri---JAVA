package romano.nahuel;

public class ProductoNuloException extends Exception{

    public ProductoNuloException(String mensaje) {
        super(mensaje);
    }
    
}
