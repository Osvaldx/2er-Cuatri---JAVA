package romano.nahuel;

public class ProductoNoEncontradoException extends Exception{

    public ProductoNoEncontradoException(String message) {
        super(message);
    }
    
}
