package romano.nahuel;

public enum Categoria {
    
    ELECTRONICA,
    MODA,
    HOGAR,
    BELLEZA,
}
