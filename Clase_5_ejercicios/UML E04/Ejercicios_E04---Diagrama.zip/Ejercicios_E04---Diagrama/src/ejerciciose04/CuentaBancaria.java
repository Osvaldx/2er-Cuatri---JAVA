package ejerciciose04;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class CuentaBancaria {

    private int claveBancaria;
    private String tipoCaja;
    private int saldo;

    public int obtenerSaldo() {
        // Método a resolver...
        return 0;
    }

    public void depositarDinero(int int1) {
        // Método a resolver...
    }

    public void extraerDinero(int int1) {
        // Método a resolver...
    }

    public int getUltimosDigitosCBU() {
        // Método a resolver...
        return 0;
    }

}