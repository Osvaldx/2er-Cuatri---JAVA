package ejerciciose02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum EstadoCivil {

    VALOR_UNO("soltero"),
    VALOR_DOS("casado"),
    VALOR_TRES("divorciado"),
    VALOR_CUATRO("viudo");
    private String valor;

    public EstadoCivil(String string1) {
        // Constructor a resolver...
    }

    public String getValor() {
        // Método a resolver...
        return "";
    }

}