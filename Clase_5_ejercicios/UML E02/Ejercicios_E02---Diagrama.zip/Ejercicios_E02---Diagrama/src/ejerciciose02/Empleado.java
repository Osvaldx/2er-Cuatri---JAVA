package ejerciciose02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Empleado implements EstadoCivil {

    private int DNI;
    private String nombre;
    private String apellido;
    private int salarioBase;
    private String estadoCivil;
    private int cantidadHijos;

    public Empleado(String string1, String string2, int int3, String string4, int int5) {
        // Constructor a resolver...
    }

    public int obtenerSalarioFinal() {
        // Método a resolver...
        return 0;
    }

}