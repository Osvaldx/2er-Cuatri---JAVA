package ejerciciose09;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Impresora implements Documento {

    private boolean estado;
    private int cantidadHojas;
    private int nivelTinta;

    public Impresora() {
        // Constructor a resolver...
    }

    public int nivelSegunCantCaracteres() {
        // Método a resolver...
        return 0;
    }

    public void recargarBandeja() {
        // Método a resolver...
    }

    public void imprimir(Documento documento1) {
        // Método a resolver...
    }

}