package ejerciciose09;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Documento {

    private String titulo;
    private LocalDate fecha;
    private String cuerpo;

    public String getTitulo() {
        // Método a resolver...
        return "";
    }

    public LocalDate getFecha() {
        // Método a resolver...
        return null;
    }

    public String getCuerpo() {
        // Método a resolver...
        return "";
    }

}