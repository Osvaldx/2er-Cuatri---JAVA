package ejerciciose03;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Persona {

    private String nombre;
    private int telefono;

    public Persona(String string1, int int2) {
        // Constructor a resolver...
    }

}