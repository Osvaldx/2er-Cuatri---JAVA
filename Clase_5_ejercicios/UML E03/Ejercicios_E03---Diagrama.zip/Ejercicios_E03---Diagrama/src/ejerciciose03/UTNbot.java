package ejerciciose03;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class UTNbot implements Persona {

    private String nombreBot;

    public UTNbot(String string1) {
        // Constructor a resolver...
    }

    public void saludar() {
        // Método a resolver...
    }

    public void saludar(Persona persona1) {
        // Método a resolver...
    }

}