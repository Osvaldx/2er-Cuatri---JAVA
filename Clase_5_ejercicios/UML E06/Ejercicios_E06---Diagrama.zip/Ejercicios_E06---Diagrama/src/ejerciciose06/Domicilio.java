package ejerciciose06;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Domicilio {

    private String calle;
    private int altura;
    private String barrio;

    public Domicilio(String string1, int int2, String string3) {
        // Constructor a resolver...
    }

    public String getDatosDomicilio() {
        // Método a resolver...
        return "";
    }

}