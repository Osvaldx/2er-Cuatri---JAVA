package ejerciciose05;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Password {

    private String valorContra;

    public Password(String string1) {
        // Constructor a resolver...
    }

    public Password() {
        // Constructor a resolver...
    }

    public boolean esFuerte() {
        // Método a resolver...
        return false;
    }

    public boolean nuevoValor(String string1) {
        // Método a resolver...
        return false;
    }

    public String generarAleatorio(int int1) {
        // Método a resolver...
        return "";
    }

}