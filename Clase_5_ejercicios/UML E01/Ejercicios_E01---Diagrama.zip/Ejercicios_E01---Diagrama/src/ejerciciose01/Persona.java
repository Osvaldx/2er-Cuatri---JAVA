package ejerciciose01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Persona {

    private String apellido;
    private String nombre;
    private LocalDate anio_nacimiento;

    Persona(String string1, String string2, LocalDate localdate3) {
        // Constructor a resolver...
    }

    public String getNombreCompleto() {
        // Método a resolver...
        return "";
    }

    public int getEdadActual() {
        // Método a resolver...
        return 0;
    }

    public boolean validacionMayorEdad() {
        // Método a resolver...
        return false;
    }

    public void setNombre(String string1) {
        // Método a resolver...
    }

    public void setApellido(String string1) {
        // Método a resolver...
    }

    public void setNombreApellido(String string1, String string2) {
        // Método a resolver...
    }

    public String mostrarInformacion() {
        // Método a resolver...
        return "";
    }

}