package ejerciciosg07;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Lavadero {

    private ArrayList<Vehiculo> vehiculos;
    private float precioAuto;
    private float precioCamion;
    private float precioMoto;
    Vehiculo sinNombre;

    public Lavadero(float float1, float float2, float float3) {
        // Constructor a resolver...
    }

    public String getDetalle() {
        // Método a resolver...
        return "";
    }

    public ArrayList<Vehiculo> getVehiculos() {
        // Método a resolver...
        return null;
    }

    public Double MostrarTotalFacturado() {
        // Método a resolver...
        return 0d;
    }

    public Double MostrarTotalFacturado(Vehiculo vehiculo1) {
        // Método a resolver...
        return 0d;
    }

    public Boolean sonIguales(Lavadero lavadero1, Vehiculo vehiculo2) {
        // Método a resolver...
        return false;
    }

    public Boolean agregar(Vehiculo vehiculo1) {
        // Método a resolver...
        return false;
    }

    public Boolean remover(Vehiculo vehiculo1) {
        // Método a resolver...
        return false;
    }

}