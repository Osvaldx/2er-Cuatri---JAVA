package ejerciciosg07;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Moto extends Vehiculo {

    protected float cilindrada;

    public Moto(String string1, Byte byte2, Marcas marcas3, float float4) {
        // Constructor a resolver...
    }

    protected String mostrarMoto() {
        // Método a resolver...
        return "";
    }

}