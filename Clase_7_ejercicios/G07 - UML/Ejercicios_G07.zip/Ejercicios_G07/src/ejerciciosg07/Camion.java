package ejerciciosg07;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Camion extends Vehiculo {

    protected float tara;

    public Camion(String string1, Byte byte2, Marcas marcas3, float float4) {
        // Constructor a resolver...
    }

    protected String mostrarCamion() {
        // Método a resolver...
        return "";
    }

}