package ejerciciosg07;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Vehiculo {

    protected String patente;
    protected Byte cantidadRuedas;
    protected Marcas marca;
    Marcas sinNombre;

    public Vehiculo(String string1, Byte byte2, Marcas marcas3) {
        // Constructor a resolver...
    }

    public String getPatente() {
        // Método a resolver...
        return "";
    }

    public Marcas getTipoMarca() {
        // Método a resolver...
        return null;
    }

    protected String mostrar() {
        // Método a resolver...
        return "";
    }

    public static Boolean sonIguales(Vehiculo vehiculo1, Vehiculo vehiculo2) {
        // Método a resolver...
        return false;
    }

}