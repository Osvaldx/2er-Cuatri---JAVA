package ejerciciosg02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ArchivoDeAudio extends ArchivoMultimedia {

    private TipoAudio formato;
    private String artista;
    private String album;
    TipoAudio sinNombre;

    public ArchivoDeAudio(String string1, int int2, String string3, Boolean boolean4, int int5, Boolean boolean6, TipoAudio tipoaudio7, String string8, String string9) {
        // Constructor a resolver...
    }

}