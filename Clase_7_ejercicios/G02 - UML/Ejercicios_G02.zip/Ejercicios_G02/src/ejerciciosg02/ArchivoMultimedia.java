package ejerciciosg02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ArchivoMultimedia extends Archivo {

    private int duracion;
    private Boolean estadoMultimedia;

    public void Multimedia(String string1, int int2, String string3, Boolean boolean4, int int5, Boolean boolean6) {
        // Método a resolver...
    }

    public String reproducir() {
        // Método a resolver...
        return "";
    }

    public String dejarReproducir() {
        // Método a resolver...
        return "";
    }

}