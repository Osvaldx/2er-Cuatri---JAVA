package ejerciciosg02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Archivo {

    private String nombre;
    private int peso;
    private String localizacion;
    private Boolean estadoArchivo;

    public Archivo(String string1, int int2, String string3, Boolean boolean4) {
        // Constructor a resolver...
    }

    public void abrirArchivo() {
        // Método a resolver...
    }

    public void cerrarArchivo() {
        // Método a resolver...
    }

    public String moverArchivo(String string1) {
        // Método a resolver...
        return "";
    }

}