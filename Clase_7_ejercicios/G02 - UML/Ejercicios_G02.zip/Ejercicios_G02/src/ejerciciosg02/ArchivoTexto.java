package ejerciciosg02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ArchivoTexto extends Archivo {

    private String codificacion;

    public void ArchivoDeTexto(String string1, int int2, String string3, Boolean boolean4, String string5) {
        // Método a resolver...
    }

    public String cifrarContenido() {
        // Método a resolver...
        return "";
    }

}