package ejerciciosg02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class ArchivoDeVideo extends ArchivoMultimedia {

    private TipoVideo formato;
    private int alto;
    private int ancho;
    TipoVideo sinNombre;

    public ArchivoDeVideo(String string1, int int2, String string3, Boolean boolean4, int int5, Boolean boolean6, TipoVideo tipovideo7, int int8, int int9) {
        // Constructor a resolver...
    }

}