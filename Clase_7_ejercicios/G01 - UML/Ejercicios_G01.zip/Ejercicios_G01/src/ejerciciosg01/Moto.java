package ejerciciosg01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Moto extends VehiculoTerrestre {

    private short cilindrada;

    public Moto(short short1, short short2, Colores colores3, short short4) {
        // Constructor a resolver...
    }

}