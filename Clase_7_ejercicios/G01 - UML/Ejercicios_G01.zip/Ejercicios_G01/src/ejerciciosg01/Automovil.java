package ejerciciosg01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Automovil extends VehiculoTerrestre {

    private short cantidadMarchas;
    private int cantidadPasajeros;

    public Automovil(short short1, short short2, Colores colores3, short short4, int int5) {
        // Constructor a resolver...
    }

}