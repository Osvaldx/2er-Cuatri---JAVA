package ejerciciosg01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Camion extends VehiculoTerrestre {

    private short cantidadMarchas;
    private int pesoCarga;

    public Camion(short short1, short short2, Colores colores3, short short4, int int5) {
        // Constructor a resolver...
    }

}