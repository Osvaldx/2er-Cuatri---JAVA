package ejerciciosg01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class VehiculoTerrestre {

    private short cantidadRuedas;
    private short cantidadPuertas;
    private Colores color;
    Colores sinNombre;

    public VehiculoTerrestre(short short1, short short2, Colores colores3) {
        // Constructor a resolver...
    }

}