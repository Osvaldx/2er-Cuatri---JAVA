package ejerciciosg01;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Colores {

    ROJO("Rojo"),
    BLANCO("Blanco"),
    AZUL("Azul"),
    GRIS("Gris"),
    NEGRO("Negro");
    private String valor;

    private Colores(String string1) {
        // Constructor a resolver...
    }

    public String getValor() {
        // Método a resolver...
        return "";
    }

}