package ejerciciof05;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public abstract class Animal {

    private String tipoEspecie;
    private String nombre;
    private LocalDate fechaNacimiento;
    private ArrayList<String> HVacunas;

    public Animal(String string1, String string2, LocalDate localdate3) {
        // Constructor a resolver...
    }

    public void addVacuna(String string1) {
        // Método a resolver...
    }

    public void removeVacuna(String string1) {
        // Método a resolver...
    }

    public void mostrarInfoAnimal() {
        // Método a resolver...
    }

}