package ejerciciof05;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Cliente {

    private String nombre;
    private String apellido;
    private int telefono;
    private String domicilio;
    private ArrayList<Animal> mascotas;
    Animal sinNombre;

    public Cliente(String string1, String string2, int int3) {
        // Constructor a resolver...
    }

    public Cliente(String string1, String string2, int int3, String string4) {
        // Constructor a resolver...
    }

    private String getNombre() {
        // Método a resolver...
        return "";
    }

    private String getApellido() {
        // Método a resolver...
        return "";
    }

    private String getDomicilio() {
        // Método a resolver...
        return "";
    }

    private ArrayList<Animal> getListaMascotas() {
        // Método a resolver...
        return null;
    }

    public void addMascota(Animal animal1) {
        // Método a resolver...
    }

    public void removeMascota(Animal animal1) {
        // Método a resolver...
    }

    public void mostrarInfoCliente() {
        // Método a resolver...
    }

}