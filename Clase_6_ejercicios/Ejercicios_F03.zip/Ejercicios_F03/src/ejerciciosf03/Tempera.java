package ejerciciosf03;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Tempera implements Color {

    private Color color;
    private String marca;
    private int cantidad;
    Paleta sinNombre;

    public Tempera(Color color1, String string2, int int3) {
        // Constructor a resolver...
    }

    private String mostrar() {
        // Método a resolver...
        return "";
    }

    public int getCantidad() {
        // Método a resolver...
        return 0;
    }

    public static String mostrar(Tempera tempera1) {
        // Método a resolver...
        return "";
    }

    public static boolean sonIguales(Tempera tempera1, Tempera tempera2) {
        // Método a resolver...
        return false;
    }

    public static boolean sonDistintos(Tempera tempera1, Tempera tempera2) {
        // Método a resolver...
        return false;
    }

    public static Tempera add(Tempera tempera1, double double2) {
        // Método a resolver...
        return null;
    }

}