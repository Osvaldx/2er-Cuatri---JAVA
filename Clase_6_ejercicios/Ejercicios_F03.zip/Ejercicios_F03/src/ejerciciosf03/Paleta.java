package ejerciciosf03;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Paleta {

    private Tempera[] colores;
    private int cantidadMaximaColores;

    public Paleta(int int1) {
        // Constructor a resolver...
    }

    public String mostrar() {
        // Método a resolver...
        return "";
    }

    private int obtenerIndice() {
        // Método a resolver...
        return 0;
    }

    private int obtenerIndice(Tempera tempera1) {
        // Método a resolver...
        return 0;
    }

    public static Boolean sonIguales(Paleta paleta1, Tempera tempera2) {
        // Método a resolver...
        return false;
    }

    public static Boolean sonDistintos(Paleta paleta1, Tempera tempera2) {
        // Método a resolver...
        return false;
    }

    public static Paleta add(Paleta paleta1, Tempera tempera2) {
        // Método a resolver...
        return null;
    }

    public static Paleta add(Paleta paleta1, Paleta paleta2) {
        // Método a resolver...
        return null;
    }

    public static Paleta remove(Paleta paleta1, Tempera tempera2) {
        // Método a resolver...
        return null;
    }

}