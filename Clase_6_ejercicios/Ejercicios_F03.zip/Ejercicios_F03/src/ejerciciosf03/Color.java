package ejerciciosf03;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public enum Color {

    ROJO("Rojo"),
    BLANCO("Blanco"),
    AZUL("Azul"),
    VERDE("Verde"),
    NEGRO("Negro");
    private String tipoColor;

    public Color(String string1) {
        // Constructor a resolver...
    }

    public String getColor() {
        // Método a resolver...
        return "";
    }

}