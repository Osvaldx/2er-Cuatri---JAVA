package ejerciciosf02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Conductor {

    private String nombre;
    private int[] kilometrosRecorridos;

    public Conductor(String string1, int[] int[]2) {
        // Constructor a resolver...
    }

    public int getDiaKilometros(int int1) {
        // Método a resolver...
        return 0;
    }

}