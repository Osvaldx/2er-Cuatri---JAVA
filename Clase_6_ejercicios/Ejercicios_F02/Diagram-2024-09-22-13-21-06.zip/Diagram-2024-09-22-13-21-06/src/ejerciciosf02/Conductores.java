package ejerciciosf02;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Conductores implements Conductor {

    private Conductor[] listaConductores;

    public Conductores(Conductor[] conductor[]1) {
        // Constructor a resolver...
    }

    public int getMaximoKilometros() {
        // Método a resolver...
        return 0;
    }

}