package ejerciciof06;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Equipo {

    private int cantidadDeJugadores;
    private String nombre;
    private ArrayList<Jugador> jugadores;
    Jugador sinNombre;

    private Equipo() {
        // Constructor a resolver...
    }

    public Equipo(int int1, String string2) {
        // Constructor a resolver...
    }

    public Equipo add(Equipo equipo1, Jugador jugador2) {
        // Método a resolver...
        return null;
    }

}