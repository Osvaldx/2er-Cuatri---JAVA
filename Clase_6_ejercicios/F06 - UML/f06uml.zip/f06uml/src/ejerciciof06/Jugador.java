package ejerciciof06;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Jugador {

    private int dni;
    private String nombre;
    private int partidosJugados;
    private float promedioGoles;
    private int totalGoles;

    private Jugador() {
        // Constructor a resolver...
    }

    public Jugador(int int1, String string2) {
        // Constructor a resolver...
    }

    public Jugador(int int1, String string2, int int3, float float4) {
        // Constructor a resolver...
    }

    public float getPromedioGoles() {
        // Método a resolver...
        return 0;
    }

    public String mostrarDatos() {
        // Método a resolver...
        return "";
    }

    public static boolean soniguales(Jugador jugador1, Jugador jugador2) {
        // Método a resolver...
        return false;
    }

    public static boolean sonDistintos(Jugador jugador1, Jugador jugador2) {
        // Método a resolver...
        return false;
    }

}