package jfxtest;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Maxi
 */
public class MiControlador {
    
    @FXML
    private Button btnAceptar;  // Referencia al botón
    
    @FXML
    private TextField txtNombre;  // Referencia al textBox
    
    @FXML
    private Label lblRespuesta;  // Referencia al label
    

    @FXML
    private void aceptarClick(ActionEvent event) {
        
        System.out.println("¡Botón Aceptar clickeado!");
       
        String rta = "Su nombre es " + this.txtNombre.getText();
        
        this.lblRespuesta.setText(rta);
    }
}
