package jfxtest;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author Maxi
 */
public class JFXTest extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        // Crear texto
        Text texto = new Text("HOLA MUNDO JAVAFX"); 
        
        // Crear panel
        GridPane panel = new GridPane();
        
        // Establecer el alineamiento del panel
        panel.setAlignment(Pos.CENTER);
        
        // Establecer color de fondo
        panel.setStyle("-fx-background-color: BEIGE;");
        
        // Agregar nodo
        panel.add(texto, 0, 0);
        
        // Crear una escena pasando el grupo, alto y ancho
        Scene scene = new Scene(panel ,300, 100); 

        // Establecer el título al escenario
        primaryStage.setTitle("Aplicación JavaFX"); 

        // Agregar la escena al escenario
        primaryStage.setScene(scene); 

        // Mostrar el contenido del escenario
        primaryStage.show(); 
    }
    
//    public static void main(String[] args) {
//
//        JFXTest.launch(args);
//    }

}
