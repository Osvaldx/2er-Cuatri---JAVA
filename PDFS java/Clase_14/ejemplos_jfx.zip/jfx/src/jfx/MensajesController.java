package jfx;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;

/**
 * FXML Controller class
 *
 * @author Maxi
 */
public class MensajesController implements Initializable {

    @FXML
    private Button btnAdvertencia;
    @FXML
    private Button btnAlerta;
    @FXML
    private Button btnInformacion;
    @FXML
    private Button btnConfirmacion;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void btnAlerta_Click(ActionEvent event) {
        System.out.println("btnAlerta clicked!");

        this.mostrarMensaje(AlertType.ERROR, "Error!!", "Contenido de la ventana");
        
    }
    
    @FXML
    private void btnAdvertencia_Click(ActionEvent event) {
        System.out.println("btnAdvertencia clicked!");

        this.mostrarMensaje(AlertType.WARNING, "Advertencia!!", "Contenido de la ventana");
        
    }
    
    @FXML
    private void btnInformacion_Click(ActionEvent event) {
        System.out.println("btnInformacion clicked!");

        this.mostrarMensaje(AlertType.INFORMATION, "Información!!", "Contenido de la ventana");
        
    }
        
    @FXML
    private void btnConfirmacion_Click(ActionEvent event) {
        System.out.println("btnConfirmacion clicked!");

        Alert ventana = new Alert(AlertType.CONFIRMATION);
        ventana.setTitle("Atención!!");
        ventana.setContentText("¿Está seguro?");
        
        ButtonType btnSi = new ButtonType("Sí");
        ButtonType btnNo = new ButtonType("No");
        
        ventana.getButtonTypes().setAll(btnSi, btnNo);
        
        Optional<ButtonType> opcion;
        
        opcion = ventana.showAndWait();
        
        if(opcion.get() == btnSi){
            System.out.println("'SI' - seleccionado");
        }
        if(opcion.get() == btnNo){
            System.out.println("'NO' - seleccionado");
            ventana.close();
        }

    }
    
    private void mostrarMensaje(AlertType tipo, String titulo, String mensaje)
    {
        Alert ventana = new Alert(tipo);
        ventana.setTitle(titulo);
        ventana.setContentText(mensaje);
        ventana.showAndWait();        
    }   
 
}
