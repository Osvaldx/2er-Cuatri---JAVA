package jfx;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Controlador {
    
    @FXML
    private void mostrarOtroForm(ActionEvent event) throws IOException{
        
        FXMLLoader cargador = new FXMLLoader(getClass().getResource("Mensajes.fxml"));
        Parent root = cargador.load();
        
        MensajesController controlador = cargador.getController();
        
        Scene escena = new Scene(root);
        Stage escenario = new Stage();
        
        escenario.initModality(Modality.WINDOW_MODAL);
        escenario.setScene(escena);
        
        escenario.showAndWait();
             
    }
}

