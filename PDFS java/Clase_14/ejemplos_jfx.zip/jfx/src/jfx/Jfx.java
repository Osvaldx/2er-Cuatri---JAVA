/*
INSTALAR JAVAFX
****************
1.- descargar https://gluonhq.com/products/javafx/
2.- descomprimir, guardar el path hasta javafx-sdk-22.0.2/lib
3.- tools -> libraries -> new library => colocar nombre (JavaFx22) -> add JAR/folder =>
=> del path (2) seleccionar todos los .jar
LISTO!!!
4.- crear proyecto nuevo -> java with ant.
5.- sobre el proyecto, botón derecho, properties -> 
-> libraries => 
    => classpath (+) -> add library (3)
    => modulepath (+) -> add library (3)
-> build -> compiling =>
    => deschecar compile on save
-> run -> VM options => --module-path "\path\to\javafx-sdk-22.0.1\lib" --add-modules javafx.controls,javafx.fxml
reemplazar "\path\to\javafx-sdk-22.0.1\lib" por el path (2)
LISTO!!!

INSTALAR SCENE BUILDER
**********************
1.- descargar https://gluonhq.com/products/scene-builder/
2.- instalar
3.- configurar desde netbeans => tools -> options -> java -> javafx -> verificar si está el path a scene buider (sino agregarlo)
LISTO!!!

 */
package jfx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Maxi
 */
public class Jfx extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        
        Scene scene = new Scene(root);
        primaryStage.setTitle("JavaFX con FXML");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Jfx.launch(args);
    }
    
}
