package filtrado;

/**
 *
 * @author Maxi
 */
public class Auto {

        private String patente;
        private int cantidadPuertas;
        private String color;


    public String getPatente() {
        return this.patente;
    }
    
    public int getCantidadPuertas() {
        return this.cantidadPuertas;
    }
    
    public String getColor() {
        return this.color;
    }

    public Auto(String patente, int cantidadPuertas, String color) {
        this.patente = patente;
        this.cantidadPuertas = cantidadPuertas;
        this.color = color;
    }

     @Override
    public String toString(){
        
        return "Patente: " + this.patente + " - cantidad puertas: " + this.cantidadPuertas + "- color: " + this.color;        
    }
    
}
