package filtrado;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 *
 * @author Maxi
 */
public class Filtrado {

    public static void main(String[] args) {

        List<Persona> personas = Arrays.asList(
                new Persona("Ana", 56, "f"),
                new Persona("Roberto", 32, "m"),
                new Persona("Ana", 18, "f"),
                new Persona("Carlos", 15, "m")
        );        
        
        // Predicate es una interface funcional, por lo tanto se puede usar con -> o referencias a métodos.
        Predicate<Persona> esMayorDeEdad = p -> ((Persona) p).getEdad() >= 18;

        // Filtramos la lista usando el Predicate
        personas.stream()
                .filter(esMayorDeEdad)
                .forEach(p -> System.out.println(p));


        Filtro<Persona> personasFiltradas = new Filtro<>();
        
        personasFiltradas.agregar( new Persona("Ana", 56, "f"));
        personasFiltradas.agregar( new Persona("Roberto", 32, "m"));
        personasFiltradas.agregar( new Persona("Anabella", 18, "f"));
        personasFiltradas.agregar( new Persona("Carlos", 15, "m"));
        
              
        List<Persona> listaConFiltroEdad = personasFiltradas.filtrar(esMayorDeEdad);

        List<Persona> listaConFiltroSexo = personasFiltradas.filtrar( p -> ((Persona)p).getSexo().equals("f"));
        
        List<Persona> listaConFiltroInicial = personasFiltradas.filtrar( p -> ((Persona)p).getNombre().startsWith("A"));
        
         
        System.out.println("FILTRO POR EDAD:");
        for(Persona p : listaConFiltroEdad){
            
            System.out.println(p);
        }

        System.out.println("FILTRO POR SEXO:");
        for(Persona p : listaConFiltroSexo){
            
            System.out.println(p);
        }

        System.out.println("FILTRO POR INICIAL:");
        for(Persona p : listaConFiltroInicial){
            
            System.out.println(p);
        }   
        
        
        Auto a1 = new Auto("aa555bb", 2, "rojo");
        Auto a2 = new Auto("cc666dd", 4, "negro");
        Auto a3 = new Auto("ee777cc", 2, "negro");
        Auto a4 = new Auto("aa555zz", 2, "azul");
        Auto a5 = new Auto("aa551bb", 4, "rojo");        
        
        Filtro<Auto> autosFiltrados = new Filtro<>();
        
        autosFiltrados.agregar(a1);
        autosFiltrados.agregar(a2);
        autosFiltrados.agregar(a3);
        autosFiltrados.agregar(a4);
        autosFiltrados.agregar(a5);
        
        System.out.println("FILTRO POR COLOR:");
        String color = "rojo";
        autosFiltrados.filtrar(a -> ((Auto)a).getColor().equals(color)).forEach(a -> System.out.println(a) );

        List<Auto> listaDeCoupes = autosFiltrados.filtrar(a -> a.getCantidadPuertas() == 2);
        
        System.out.println("SOLO COUPES:");
        for(Auto a : listaDeCoupes){
            
            System.out.println(a);
        }
        
    }
    
}
