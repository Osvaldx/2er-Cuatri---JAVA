package filtrado;

/**
 *
 * @author Maxi
 */
public class Persona {

    private String nombre;
    private Integer edad;
    private String sexo;

    public String getNombre() {
        return this.nombre;
    }

    public Integer getEdad() {
        return this.edad;
    }
    
    public String getSexo() {
        return this.sexo;
    }      
    public Persona(String nombre, int edad, String sexo) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
    }
       
    @Override
    public String toString(){
        
        return "Nombre: " + this.nombre + " - edad: " + this.edad + "- sexo: " + this.sexo;
        
    }

}
