package filtrado;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 *
 * @author Maxi
 * @param <T>
 */
public class Filtro<T> {

    private List<T> items;
    
    public Filtro(){
        this.items = new ArrayList<>();
    }
    
    public void agregar(T item) {
        this.items.add(item);
    }
   
    public List<T> filtrar(Predicate<T> criterio) {

        List<T> resultado = new ArrayList<>();

        for (T item : items) {
    
            if (criterio.test(item)) {
                resultado.add(item);
            }
        }
        
        return resultado;
    }
      
}
