package serializacion;


/**
 * descargar el .jar desde: https://mvnrepository.com/artifact/com.google.code.gson/gson
 * agregar el .jar en alguna carpeta del proyecto.
 * desde el proyecto: properties->libraries->Compile --> classpath >> agregar el .jar
 * @author maxin
 */
public class Auto {
    
    private String patente;
    private int modelo;

    public Auto(String patente, int modelo) {
        this.patente = patente;
        this.modelo = modelo;
    }

    @Override
    public String toString() {
        return "Auto [patente=" + this.patente + ", modelo=" + this.modelo + "]";
    }
}
