package serializacion;

import com.google.gson.Gson;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author maxin
 */
public class Serializacion {

    public static void main(String[] args) {
        
        Serializacion.serializacionBinaria();
        
        Serializacion.serializacionJSON();
    }
    
    private static void serializacionBinaria(){
        
        Persona persona = new Persona("Juan", 30);

        // Serialización
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("persona.dat"))) {
            
            out.writeObject(persona);
            
            System.out.println("Objeto serializado: " + persona);
            
        } catch (IOException e) {
            System.out.println("ERROR: " + e.getMessage());
        }

        // Deserialización
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("persona.dat"))) {
            
            Persona personaDeserializada = (Persona) in.readObject();
            
            System.out.println("Objeto deserializado: " + personaDeserializada);
            
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
    
    private static void serializacionJSON(){
        
        Auto auto = new Auto("AYF714", 1996);
        
        // Convertir objeto a JSON
        Gson gson = new Gson();
        String json = gson.toJson(auto);
        
        System.out.println("Objeto en JSON: " + json);
        
        // Convertir JSON a objeto
        Auto autoDesdeJson = gson.fromJson(json, Auto.class);
        System.out.println("Objeto desde JSON: " + autoDesdeJson);
    }
}
